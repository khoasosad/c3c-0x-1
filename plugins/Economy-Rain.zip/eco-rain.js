function sizeObject(object) {
  return Object.keys(object).length;
}

var rainallfunc = function rainallfunc(type, data) {
	var Economy = global.plugins.economy;
	if (data.args.length > 1) {
		var id = Economy.getID(data.msgdata, type);
		var totalMoney = Economy.parseValue(id, data.args[1]);
		var countUsers = sizeObject(global.data.economy) - 1;
		if (isNaN(totalMoney)) {
			return {
				handler: "internal",
				data: "Error: NaN!"
			}
		} else if (!Economy.validBalance(id, totalMoney)) {
			return {
				handler: "internal",
				data: "Not enough money.\r\nHave: {0}, need: {1}".replace("{0}", global.data.economy[global.plugins.economy.getID(data.msgdata, type)].floor(2)).replace("{1}", Math.abs(totalMoney).floor(2))
			}
		} else if (Math.abs(totalMoney) == 0) {
			return {
				handler: "internal",
				data: "Cannot rain 0."
			}
		}
		var eachUsers = Math.abs(totalMoney) / countUsers;
		global.plugins.economy.operator.subtract(global.plugins.economy.getID(data.msgdata, type), Math.abs(totalMoney), "Rainall");
		for (var ids in global.data.economy) {
			if (ids != id) {
				global.plugins.economy.operator.add(ids, eachUsers, "Rainall from " + id);
			}
		}
		return {
			handler: "internal",
			data: "Rained " + countUsers + " wallet. (" + eachUsers.floor(2) + global.plugins.economy.getSymbol() + " each)"
		}
	} else {
		return {
			handler: "internal",
			data: "Invalid arguments!"
		}
	}
}

module.exports = {
	rainallfunc: rainallfunc
}