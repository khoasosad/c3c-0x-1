var fetch = global.nodemodule["node-fetch"];

var Adminbot_get = function Adminbot_get(type, data) {
	(async function () {
        var returntext = `|WELCOME| Chào Mừng Đến PixelBot
        |ConTact|
Admin: Nguyễn Khoa
FB: https://www.facebook.com/khoadayy.12
[Lưu ý] : Vui lòng không spam khi sử dụng và trân thành cảm ơn bạn đã sử dụng sản phẩm
[Lưu ý]: Đừng có dại dột mà add 2 bot kẻo bị phát hiện là bạn toang đó <3
[Cảnh báo]: Vui lòng không dùng bot với mục đích xấu hay cố ý report acc facebook
Chúc bạn sử dụng vui vẻ <3
PixelFromVN 2021`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	Adminbot_get: Adminbot_get
}