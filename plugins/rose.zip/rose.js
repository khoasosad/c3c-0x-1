var fetch = global.nodemodule["node-fetch"];

var rose = function rose(type, data) {
	(async function () {
		var returntext = `Cần lao vi tiên thủ, năng cán dĩ đắc thực, vô vi thực đầu buồi, thực cứt thế cho nhanh"`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"GIOI THIEU\" by Khoa";

data.log(onLoadText);

}
module.exports = {
	rose: rose
}