var srequest = global.nodemodule["sync-request"];

var simsimi = function(type, data){
	var word = data.msgdata.body.slice(6, data.msgdata.body.length);
	return {
		handler: "internal",
		data: JSON.parse((srequest('GET', `https://simsimi.copcute.pw/api/sim.php`, { qs: { text: word }}).body)).messages[0].text
	}
}

var simteach = async function(type, data){
	var args = data.msgdata.body.slice(10, data.msgdata.body.length).split('"');
	if(args.length != 5){
		var msg = `Sai cú pháp simteach: ${global.config.command}daysim "từ/câu bạn muốn sim trả lời khi bạn chat" "từ/câu bạn muốn Simsimi trả lời"`;
	}
	else {
		var key = args[1];
		var value = args[3];
		console.log(key, value);
		if((key == "" || value == "") || (key == " " || value == " ")){
			var msg = `Sai cú pháp simteach: từ/câu bạn muốn sim trả lời khi bạn chat và từ/câu bạn muốn Simsimi trả lời không được để trống!`;
		}
		else {
			var value3 = teach(key, value);
			var msg = `Cảm ơn bạn đã dạy cho Simsimi 1 kiến thức mới ^^\r\nKey: ${value3.ask}\r\nValue: ${value3.ans}`;
		}
	}
	return{
		handler: "internal",
		data: msg
	}
}

function teach(x, y) {
	var value1 = x;
	var value2 = y;
	var value3 = JSON.parse(srequest('GET', `https://simsimi.copcute.pw/api/save.php`, { qs: { hoi: value1, dap: value2 }}).body);
	return {
		ask: value3.ask,
		ans: value3.ans
	};
}

module.exports = {
	simsimi,
	simteach
}