var fetch = global.nodemodule["node-fetch"];

var khabanh= function khabanh(type, data) {
	(async function () {
		var returntext = `Sức đề kháng yếu là do bạn chưa chơi đồ đấy bạn à=)))`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"GIOI THIEU\" by Khoa";

data.log(onLoadText);

}
module.exports = {
	khabanh: khabanh
}