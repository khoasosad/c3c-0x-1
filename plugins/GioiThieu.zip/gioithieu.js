var fetch = global.nodemodule["node-fetch"];

var gioithieu = function gioithieu(type, data) {
	(async function () {
		var returntext = `AdminBOT là một chatbot được lập trình sẵn, dùng cho cá nhân, cho các boxchat khác, với rất nhiều tiện ích.
Là chương trình mã nguồn mở, vì thế sẽ có nhiều tính năng (plugins).
Facebook Admin: https://www.facebook.com/profile.php?id=100055918998935
Được phát triển bởi chủ bot, có thể tự viết plugins hoặc ngửa tay đi xin plugins của người khác. :)
Mong bạn có trải nghiệm tốt về AdminBOT.`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

function onLoad(data) {

var onLoadText = "Loaded \"GIOI THIEU\" by Wua'n";

data.log(onLoadText);

}
module.exports = {
	gioithieu: gioithieu
}