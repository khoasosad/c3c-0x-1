var fetch = global.nodemodule["node-fetch"];
var wait = global.nodemodule['wait-for-stuff'];
var path = global.nodemodule["path"];
var streamBuffers = global.nodemodule["stream-buffers"]

var num = async function (type, data) {

	//thông tin box
	var adinfo = await data.facebookapi.getThreadInfo(data.msgdata.threadID);

   //admin
	var numqtv = adinfo.adminIDs.length;
	var adminIDs = adinfo.adminIDs.map(x => x.id.toString());
	var nameadmin = [];
    for (var i = 0; i < adminIDs.length; i++) {
    	cname = global.data.cacheName["FB-" + adminIDs[i]];
    	await nameadmin.push(cname);
    } 
   //số lượng thành viên
	var memLength = adinfo.participantIDs.length;
	//gender    

    var nameMen = [];
    var gendernam = [];
    var gendernu = [];
    var nope = [];
     for (let z in adinfo.userInfo) {
     	var gioitinhone = adinfo.userInfo[z].gender;
     	var nName = adinfo.userInfo[z].name;
        if(gioitinhone == "MALE"){gendernam.push(z+gioitinhone)}
        else if(gioitinhone == "FEMALE"){gendernu.push(gioitinhone)}
            else{nope.push(nName)}
            	
    
    };
    
    
     var nam = gendernam.length;
     var nu = gendernu.length;
	//emoji
    let emoji = adinfo.emoji;
    //số tin nhắn
    let count = adinfo.messageCount
   
  //lấy ảnh box
		var imgX = adinfo.imageSrc;
		var fetchimgD = await fetch(imgX);
		var buffer = await fetchimgD.buffer();
		var imagesx = new streamBuffers.ReadableStreamBuffer({
			frequency: 10,
			chunkSize: 1024
		});
		imagesx.path = 'image.png';
		imagesx.put(buffer);
		imagesx.stop();

			return {
				handler: "internal",
				data: {
					body: "⭐️Box: "+ adinfo.name +  
					      "\n👨‍👩‍👧‍👦Số mem: " + memLength +
					      "\n👦Nam: " +nam+
					      "\n👩Nữ: " +nu+
					      "\n👀Phi giới tính: "+nope.length+
					      "\n"+nope.join(",")+
					      "\n🧠Emoji: "+emoji+
					      "\n👤Số QTV: " + numqtv +"("+nameadmin.join(",")+")"+
					      "\n👂Số countbox: " + count,
					attachment: ([imagesx])
				}
			}

	}


module.exports = {
	num: num
}